<!--
<p align="center" ><img src="https://raw.githubusercontent.com/kaizoku-oh/kaizoku-oh/master/static/myintro.gif"/></p>
-->

</div>

<h3 align="center">Connect with me</h3>
<p align="center">
  <a href= "https://www.linkedin.com/in/carlos-fernando-tovar-ceron/"><img src="https://img.icons8.com/dusk/48/000000/linkedin.png"/></a>
  <a href= "https://medium.com/@cartovarc"><img src="https://img.icons8.com/dusk/48/000000/medium-new.png"/></a>
  <a href= "https://twitter.com/cartovarc"><img src="https://img.icons8.com/dusk/48/000000/twitter.png"/></a>
  <a href= "https://www.youtube.com/channel/UCED79TelBGrG7guDFqD8qBA"><img src="https://img.icons8.com/dusk/48/000000/youtube--v2.png"/></a>
</p>

<p>
  <img align="left" width="490" height="165" src="https://github-readme-stats.vercel.app/api/?username=cartovarc&show_icons=true&title_color=fffffff&icon_color=000000&text_color=000000&count_private=true" alt="github stats"/>
  <a href="https://github.com/anuraghazra/github-readme-stats">
    <img align="center" src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=cartovarc&hide=html" />
  </a>
  <p>
    <img src="https://views.whatilearened.today/views/github/cartovarc/views.svg"/>
    <a href="https://github.com/cartovarc?tab=followers"><img src="https://img.shields.io/github/followers/cartovarc?color=%234CC61E&label=GitHub%20Followers%20%3A"/></a>
    <a href="https://github.com/cartovarc?tab=repositories"><img src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"/></a>
    <a href="https://github.com/Naereen/badges"><img src="https://img.shields.io/badge/badges-awesome-green.svg"/></a>
    <a href="mailto:cartovarc@gmail.com?subject=[Github] Ask me anything&body=Hello Carlos, I am sending this after seeing your Github Profile"><img src="https://img.shields.io/badge/Ask%20me-anything-1abc9c.svg"/></a>
    <img src="https://img.shields.io/badge/Os-Ubuntu-a80030"/>
  </p>
</p>
<br/><br/>

- 🔭 I’m currently working on an drone aerial surveillance software solution
- 🌱 I’m currently learning Kubernetes and Docker
- 👯 I’m looking to collaborate on developer tools for drones projects
- 💬 Ask me about DJI SDK
- 📫 How to reach me: you can reach me from the social media links above
- 😄 Pronouns: he/him
- ⚡ Languages: C, C++, Python, Java, Javascript
